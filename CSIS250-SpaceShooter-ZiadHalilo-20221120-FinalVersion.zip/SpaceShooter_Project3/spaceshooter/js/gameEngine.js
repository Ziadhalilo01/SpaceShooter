var keysDown = {};

addEventListener("keydown", function (e) {

    keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) {
    delete keysDown[e.keyCode];
}, false);


class Game {
    constructor() {
        this.canvas = document.getElementById("myCanvas");
        this.ctx = this.canvas.getContext("2d");
        this.sprites = [];
        this.background = new Image();
        this.x = 0;
        this.y = 0;
        this.width = this.canvas.width;
        this.height = this.canvas.height;
        this.speed = 6;
        this.gameEnds = false;
        this.audio = new Audio();
        this.audio.src = 'assets/mp3/ambience-sounds.mp3';     
    }

    update() {
        var ldeletedArray = [];
        var lSpritesLength = this.sprites.length;
        for (var i = 0; i < lSpritesLength; i++) {
            var object = this.sprites[i].update();
            if (object) {
                ldeletedArray.push(this.sprites[i]);
            }

        }

        for (var i = 0; i < ldeletedArray.length; i++) {
            var index = this.sprites.indexOf(ldeletedArray[i]);
            this.sprites.splice(index, 1);
        }
        this.y += this.speed;
        if (this.y > this.height) this.y = 10;
    }


    draw() {
        this.background.src = "img/62.png";
        this.ctx.drawImage(this.background, this.x, this.y);
        this.ctx.drawImage(this.background, this.x, this.y - this.height + this.speed);
        this.audio.play();

        var lSpriteLength = this.sprites.length;
        for (var i = 0; i < lSpriteLength; i++) {
            this.sprites[i].draw(this.ctx);

        }
    }

    addSprite(pSprite) {
        this.sprites.push(pSprite);
    }

}

class Sprite {
    constructor() {

    }
    update() {

    }

    draw() {
    }
}

class Backgroundinfo extends Sprite {
    constructor(user, g) {
        super();

        this.user = user;
        this.play = false;
        this.pause = 0; 
        this.begin = this.user.horizontalspeed; 
        this.gameover = false;
        this.g = g;


    }

    update() {

        if (13 in keysDown) {
            this.play = true;
            this.gameover = false;
            this.user.x = this.user.x;
            this.user.y = this.user.y;
            this.user.horizontalspeed = this.begin;
        }
    }


    draw(ctx) {
        if (this.g.gameEnds) {
            ctx.fillStyle = "#FFFFFF";
            ctx.font = "19px Courier New";
            ctx.fillText("Gameover: ", 800 - 500, 600 - 260);
            ctx.fillText("Try again  ", 800 - 500, 600 - 230);
            ctx.fillText("Press ctrl+R to restart the game ", 800 - 528, 600 - 200);
            ctx.beginPath();

            ctx.fill();
        }

        if (!this.play) {
            console.log("not play");

            this.user.x = 800 - 440;
            this.user.y = 600 - 140;
            this.user.horizontalspeed = this.pause;
            ctx.fillStyle = "#FFFFFF";
            ctx.font = "19px Courier New";
            ctx.fillText("\t\tPRESS ENTER TO PLAY " + "", 800 - 528, 600 - 260);
            ctx.fillText("Life: " + this.user.lives, 800 / 8, 600 / 7);
            ctx.fillText("Score: " + this.user.userScore, 600, 600 / 7);
            ctx.beginPath();
            ctx.rect(this.x, this.y, this.width, this.height);
            ctx.fillStyle = this.color;
            ctx.fill();


        } else {
            console.log("play");
            user.horizontalspeed = this.begin;
            ctx.fillStyle = "#FFFFFF";
            ctx.font = "19px Courier New";
            ctx.fillText("Life: " + this.user.lives, 800 / 8, 600 / 7);
            ctx.fillText("Score: " + this.user.userScore, 600, 600 / 7);


            ctx.beginPath();

            ctx.fill();
        }
    }
}

class userController extends Sprite {
    constructor(x, y, width, height, color, horizontalspeed, myGame, enemy_1) {
        super();
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
        this.horizontalspeed = horizontalspeed;
        this.verticalspeed = 3;
        this.myGame = myGame;
        this.enemy = enemy_1;
        this.shots = [];
        this.lives = 2000;
        this.userScore = 0;


        this.index = 0;
        this.image = new Image();

    }

    update() {

        if (39 in keysDown) { 
            if (this.x < 700)
                this.x += this.horizontalspeed;
        }

        if (37 in keysDown) { 
            if (this.x >= 0)
                this.x -= this.horizontalspeed;
        }

        if (40 in keysDown) { 
            if (this.y < 500)
                this.y += this.verticalspeed + 4;
        }

        if (38 in keysDown) { 
            if (this.y >= 0)
                this.y -= this.verticalspeed + 2;
        }


        if (32 in keysDown) {

            if (this.index > 10 || this.index < 1) {
                var usernextshot = new userBullet(this);
                this.shots.push(usernextshot);
                this.myGame.addSprite(usernextshot);

                this.index = 0;
            }
            this.index++;
        }

        for (let i = 0; i < enemybullets1.length; i++) {
            if (!enemybullets1[i].used)
                if ((enemybullets1[i].y < this.y + 150 && enemybullets1[i].y > this.y) &&
                    (enemybullets1[i].x > this.x && enemybullets1[i].x < this.x + 100)) {
                    this.lives -= 500;
                    enemybullets1[i].used = true;
                    if (this.lives == 0) {
                        this.myGame.gameEnds = true;
                        return true;
                    }
                }
        }
    }

   

    draw(context) {
        this.image.src = "img/userplane.png";
        context.fillStyle = this.color;
        context.beginPath();
        context.drawImage(this.image, this.x, this.y);

        context.fill();
    }
}

var enemybullets1 = [];
class enemyBullet extends Sprite {
    constructor() {
        super();
        this.used = false;
        this.x = 0;
        this.y = 0;


    }

    update() {
        this.y += 3;
        if (!enemybullets1.includes(this)) {
            enemybullets1.push(this);
        }



    }


    draw(context) {
        context.fillStyle = "#FF0000";
        context.beginPath();
        context.rect(this.x, this.y, 10, 10);
        context.fill();
    }

}

class userBullet extends Sprite {
    constructor(userplane) {
        super();
        this.userplane = userplane;
        this.x = this.userplane.x + 50;
        this.y = this.userplane.y;


        this.verticalspeed = 2;


    }

    update() {
        
        this.y -= this.verticalspeed;
    }


    draw(context) {
        context.fillStyle = "#F67280";
        context.beginPath();
        context.rect(this.x, this.y, 10, 10);
        context.fill();
    }

}

class enemy extends Sprite {
    constructor(x, y, enemybullet, myGame, user) {
        super();
        this.x = x;
        this.y = y;
        this.horizontalspeed = 1;
        this.verticalspeed = 1;
        this.enemybullet = enemybullet;
        this.enemybullet.x = this.x + 50;
        this.enemybullet.y = this.y + 80;
        this.image = new Image();
        this.index = 0;
        this.user = user;
        this.myGame = myGame;

        this.enemybullets = [];

    }

    update() {


        if (this.x > 800) {
            this.horizontalspeed = -this.horizontalspeed;
            this.verticalspeed = this.verticalspeed;
        }

        if (this.x < -300) {
            this.horizontalspeed = this.horizontalspeed + 1;
            this.verticalspeed = this.verticalspeed;
        }


        if (this.y > 800) {
            this.y = -200;
        }

        if (this.y < -300) {
            this.horizontalspeed = this.horizontalspeed;
            this.verticalspeed = -this.verticalspeed;
        }


        this.x += this.horizontalspeed;
        this.y += this.verticalspeed;


        if (this.index > 100 || this.index < 1) {
            var nextshot = new enemyBullet();
            var eeee = new enemy(this.x, this.y, nextshot, this.myGame);
            this.myGame.addSprite(nextshot);
            this.enemybullets.push(nextshot);

            this.index = 0;
        }
        this.index++;



        for (let i = 0; i < this.user.shots.length; i++) {
            if ((this.user.shots[i].x > this.x && this.user.shots[i].x < this.x + 100) &&
                (this.user.shots[i].y > this.y && this.user.shots[i].y < this.y + 112)) {
                this.user.userScore += 100;
                return true;
            }
        }

    }


    draw(context) {
        this.image.src = "img/enemy.png";
        context.fillStyle = this.color;
        context.beginPath();
        context.drawImage(this.image, this.x, this.y);
        context.fill();
    }
}

window.requestAnimFrame = (function () {
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        function (callback) {
            window.setTimeout(callback, 1000 / 60);
        };
})();
