var myGame = new Game();
var user = new userController(600, 500, 90, 10, "#FFFFFF", 5, myGame, enemies);

for (let i = -100; i < 4000; i += 150) {
	var e_bullet = new enemyBullet();
	var enemies = new enemy(-200 + i, -300, e_bullet, myGame, user);
	enemies.horizontalspeed += 0.13;
	enemies.verticalspeed += 0.13;

	if (i >= 1250) {
		var e_bullet = new enemyBullet();
		var enemies = new enemy(-200 + i, -300 + i, e_bullet, myGame, user);
		enemies.horizontalspeed += 0.13;
		enemies.verticalspeed += 0.13;
	}


	var layer = new Backgroundinfo(user,myGame);
	myGame.addSprite(enemies);
}
myGame.addSprite(user);
myGame.addSprite(layer);

function animate(game) {
		game.update();
		game.draw();

		requestAnimFrame(function () {
			animate(game);
		});
	

}

animate(myGame);


